package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Orientation;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.util.ArrayList;

/**
 *
 * @author maggie
 */
class SortByTime extends SortSwimmers{
   // ListView<String> listLeft;
    ObservableList<Swimmer> list = FXCollections.observableArrayList();


    public  void sort( ArrayList<Swimmer> datas){

        System.out.println("ID_______Name______Sex______age_______season_______computation Result");
        int i =0;
        //list.add("S_name      age   result   season   Age Group");
        for(Swimmer data : datas){

           // System.out.println(i+"________"+data.name+"_____"+data.sex+"________"+data.age+"_________"+data.season+"______________"+data.result);
            i++;

            //list.add(data.name+"        "+data.age+"       "+data.result+"        "+data.season+"       "+data.age_group);
            list.add(data);

        }
       // listLeft.getItems().addAll(list);

        //listLeft.getItems().addAll(




    }
    public ObservableList<Swimmer> list(ArrayList<Swimmer> datas){

        sort( datas);
        return list;

    }

}
