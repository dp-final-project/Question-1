package sample;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.util.*;
//import static swimmers.Database.insertData;
//import static swimmers.Database.table_name;
//import static swimmers.Swimmers.connection;

/**
 *
 * @author maggie
 */
class SwimmersData implements Cloneable {
    static String table_name[]={"age_group16_20","age_group21_25","age_group26_30","age_group31_35"};

    static Connection connection = null;
    static String database = "";
    static String url ="jdbc:mysql://localhost:3306/" +database;
    static String username = "root";
    static String password ="root";


    static ArrayList<Swimmer> catchedData = new ArrayList<Swimmer>();


    public  void fetchData(String table_name) throws SQLException{
        connection =DriverManager.getConnection(url, username, password);
        String query ="SELECT * FROM `swimmerdatabase`. `"+table_name+"`";
        PreparedStatement ps = connection.prepareStatement(query);
        // execute the query, and get a java resultset
        ResultSet rs = ps.executeQuery(query);

        // iterate through the java resultset
        while (rs.next())
        {
            grwonUp(rs);

            Swimmer swimmer = new Swimmer();

            swimmer.setName(rs.getString("name"));
            swimmer.setSeason(rs.getInt("season"));
            swimmer.setAge_group(rs.getInt("age_group"));
            swimmer.setResult(rs.getInt("comp_result"));
            swimmer.setMaxAge(rs.getInt("max_age"));
            swimmer.setSex(rs.getString("sex"));
            swimmer.setBirthOfDate(rs.getDate("birth_of_date"));
            swimmer.setAge(rs.getInt("age"));
            swimmer.setId(rs.getInt("id"));

            catchedData.add(swimmer);



            int id = rs.getInt("id");
            String firstName = rs.getString("name");
            int age = rs.getInt("age");
            Date birthOfDate= rs.getDate("birth_of_date");
            int season = rs.getInt("season");
            int result= rs.getInt("comp_result");
            //data_1.add(rs);

// print the results

            //  System.out.format("%s, %s, %s, %s, %s ,%S\n", id, firstName,age, dateCreated, numPoints,season);
            // data_1.add(new Swimmer(firstName,numPoints,season,1));

        }
    }

    public  void viewData() throws SQLException{

        for(int season =1; season <=4;season++){

            fetchData(table_name[season-1]);

        }
    }

    public Object clone(){
        Object clone = null;
        try {
            clone=super.clone();
        }catch (CloneNotSupportedException e){
            e.printStackTrace();
        }
        return clone;}

    public ArrayList<Swimmer> getSwimmersCollection(){
        Collections.sort(catchedData, new Comparator<Swimmer>() {

            @Override
            public int compare(Swimmer t, Swimmer t1) {
                return t.result - t1.result;
            }
        });
        return catchedData;
    }

    public  void grwonUp(ResultSet rs) throws SQLException {
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("MM-dd ");
        // System.out.println(formatter.format(date));
        Date bDate =rs.getDate("birth_of_date");
        SimpleDateFormat formatter2 = new SimpleDateFormat("MM-dd ");
        String format=formatter.format(bDate);



        String update ="age";
        if (format.equals(formatter.format(date))){

            // update(int age_group,int id,String col_name,int value)
            Database.update(rs.getInt("age_group"),rs.getInt("id"),update,rs.getInt("age")+1);


        }
        if (rs.getInt("age")==rs.getInt("max_age")){
            Database.insertData(rs.getInt("age_group")+1,rs.getString("name"),rs.getString("sex"),rs.getDate("birth_of_date"),rs.getInt("age"),rs.getInt("comp_result"),rs.getInt("season"),rs.getInt("age_group"),rs.getInt("max_age"));
            Database.deleteSpecificData(rs.getInt("id"),rs.getInt("age_group"));
        }



    }


}
