package sample;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Random;
//import static swimmers.Main.sData;
//import static swimmers.Swimmers.connection;
//import static swimmers.Swimmers.table_name;

/**
 *
 * @author maggie
 */
public class Database {

    static Connection connection = null;
    static String database = "";
    static String url ="jdbc:mysql://localhost:3306/" +database;
    static String username = "root";
    static String password ="root";
    static String table_name[]={"age_group16_20","age_group21_25","age_group26_30","age_group31_35"};
    Random rand = new Random();
   // SwimmersData sData= new SwimmersData();


    public static void insertData(int ageGroup,String name,String sex,Date bDate,int age,int result,int season,int age_group,int max_age) throws SQLException{

        String query = "INSERT INTO `swimmerdatabase`.`"+table_name[ageGroup-1]+"`(`name`,`sex`,`age`,`birth_of_date`,`comp_result`,`season`,`age_group`,`max_age`) VALUES ('"+name+"','"+sex+"',"+age+","+bDate+","+result+","+season+","+age_group+","+max_age+"); ";
        PreparedStatement ps = connection.prepareStatement(query);
//        java.util.Date now = new java.util.Date();
//        Random rand = new Random();
//        int minDay = (int)LocalDate.of(1984, Month.JANUARY,1).toEpochDay();
//        int maxDay = (int)LocalDate.of(2019, 2,3).toEpochDay();
//        long randomDay = minDay+rand.nextInt(maxDay-minDay);
//        LocalDate birthOfDate = LocalDate.ofEpochDay(randomDay);

        //LocalDate now = new LocalDate.now().minus(Period.ofDays((Random.nextInt(365*70))));
       // ps.setDate( 1, java.sql.Date.valueOf(birthOfDate));
        int status = ps.executeUpdate();
        if(status !=0){

            System.out.println("database connected");}
    }
    public static void deleteData(String table_name) throws SQLException{
        //PreparedStatement ps = connection.prepareStatement("DELETE FROM `studentdatabse`.`student` WHERE Id = '"+id+"'"; ");

        String query= "DELETE FROM `swimmerdatabase`.`"+table_name+"`";// WHERE ";//`id` = "+id+"; ";
        //= "delete from studentdatabase.student where id = ?";
        PreparedStatement ps = connection.prepareStatement(query);
        int status = ps.executeUpdate();
        if(status !=0){

            System.out.println("database connected and deleted");}

    }
    public static void update(int age_group,int id,String col_name,int value) throws SQLException{
        String query = "UPDATE `swimmerdatabase`.`"+table_name[age_group-1]+"` SET `"+col_name+"` ="+value+" where id ="+ id;
        PreparedStatement ps = connection.prepareStatement(query);
        int status = ps.executeUpdate();
        if(status !=0){

            System.out.println("database connected and updated");}

    }
    public static void deleteSpecificData(int id,int age_group) throws SQLException{
        String query= "DELETE FROM `swimmerdatabase`.`"+table_name[age_group]+"`WHERE `id`="+id;
        //= "delete from studentdatabase.student where id = ?";
        PreparedStatement ps = connection.prepareStatement(query);
        int status = ps.executeUpdate();
        if(status !=0){

            System.out.println("database connected and deleted");}

    }

    public void addData() throws SQLException{
        java.util.Date now = new java.util.Date();
        Random rand = new Random();
        int minDay = (int)LocalDate.of(1984, Month.JANUARY,1).toEpochDay();
        int maxDay = (int)LocalDate.of(2019, 2,3).toEpochDay();
        long randomDay = minDay+rand.nextInt(maxDay-minDay);
        LocalDate birthOfDate = LocalDate.ofEpochDay(randomDay);
        int age =16;
        for(int season =1; season <=4;season++){

            for(int swimmers =1; swimmers<12; swimmers++){
                // deleteData(table_name[season-1]);
                String sex;
                int sex1=rand.nextInt(2);
                if(sex1==1){
                    sex="F";
                }else{
                    sex="M";
                }
                insertData(season,"name"+swimmers,sex,java.sql.Date.valueOf(birthOfDate),age+rand.nextInt(5),rand.nextInt(101),1+rand.nextInt(4),season,age+15);

            }
            System.out.println("*************************************"+table_name[season-1]+"*****************************************************");
//fetchData(table_name[season-1]);
            age+=5;
        }
    }

//         public SwimmersData getSwimmersData(){
//
//         return (SwimmersData)sData.clone();
//
//     }
}

