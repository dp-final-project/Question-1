package sample;

import java.util.ArrayList;

/**
 *
 * @author maggie
 */
public abstract class SortSwimmers {

    /**
     *
     */
    //final const static ArrayList<swimmerData> data_1;
    public abstract  void sort(ArrayList<Swimmer> datas);

}