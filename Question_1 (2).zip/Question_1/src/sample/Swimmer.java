package sample;



import java.sql.Date;

/**
 *
 * @author maggie
 */
public class Swimmer {
    public String name;
    public int season;
    public int result;

    public int age_group;
    public int max_age;

    public int age;
    public int id;
    public String sex;
    Date birthOfDate;

    public String getName() {
        return name;
    }

    public int getSeason() {
        return season;
    }

    public int getResult() {
        return result;
    }

    public int getAge_group() {
        return age_group;
    }
    public int getAge() {
        return age;
    }
    public String getSex() {
        return sex;
    }



    public Swimmer(){

    }

    public void setName(String name){

        this.name=name;
    }
    public void setSeason(int s){

        this.season=s;
    }
    public void setResult(int result){

        this.result=result;
    }
    public void setAge_group(int age_group){

        this.age_group=age_group;
    }
    public void setMaxAge(int maxAge){

        this.max_age=maxAge;}
    public void setSex(String sex){
        this.sex=sex;
    }

    public void setBirthOfDate(Date birthOfDate){
        this.birthOfDate = birthOfDate;
    }
    public void setAge(int age){
        this.age=age;
    }

    public void setId(int id){
        this.id=id;}


}
