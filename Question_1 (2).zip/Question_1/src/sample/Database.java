package sample;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Random;
//import static swimmers.Main.sData;
//import static swimmers.Swimmers.connection;
//import static swimmers.Swimmers.table_name;

/**
 *
 * @author maggie
 */
public class Database {

    static Connection connection = null;
    static String database = "";
    static String url ="jdbc:mysql://localhost:3306/" +database;
    static String username = "root";
    static String password ="root";
    static String table_name[]={"age_group16_20","age_group21_25","age_group26_30","age_group31_35"};
    Random rand = new Random();
    private static Database instance = new Database();
   // SwimmersData sData= new SwimmersData();
private Database(){}

    public static void insertData(int ageGroup,String name,String sex,Date bDate,int age,int result,int season,int age_group,int max_age) throws SQLException{

        String query = "INSERT INTO `swimmerdatabase`.`"+table_name[ageGroup-1]+"`(`name`,`sex`,`age`,`birth_of_date`,`comp_result`,`season`,`age_group`,`max_age`) VALUES ('"+name+"','"+sex+"',"+age+","+bDate+","+result+","+season+","+age_group+","+max_age+"); ";
        PreparedStatement ps = connection.prepareStatement(query);
//        java.util.Date now = new java.util.Date();
//        Random rand = new Random();
//        int minDay = (int)LocalDate.of(1984, Month.JANUARY,1).toEpochDay();
//        int maxDay = (int)LocalDate.of(2019, 2,3).toEpochDay();
//        long randomDay = minDay+rand.nextInt(maxDay-minDay);
//        LocalDate birthOfDate = LocalDate.ofEpochDay(randomDay);

        //LocalDate now = new LocalDate.now().minus(Period.ofDays((Random.nextInt(365*70))));
       // ps.setDate( 1, java.sql.Date.valueOf(birthOfDate));
        int status = ps.executeUpdate();
        if(status !=0){

            System.out.println("database connected");}
    }
    public static void deleteData(String table_name) throws SQLException{
        //PreparedStatement ps = connection.prepareStatement("DELETE FROM `studentdatabse`.`student` WHERE Id = '"+id+"'"; ");

        String query= "DELETE FROM `swimmerdatabase`.`"+table_name+"`";// WHERE ";//`id` = "+id+"; ";
        //= "delete from studentdatabase.student where id = ?";
        PreparedStatement ps = connection.prepareStatement(query);
        int status = ps.executeUpdate();
        if(status !=0){

            System.out.println("database connected and deleted");}

    }
    public static void update(int age_group,int id,String col_name,int value) throws SQLException{
        String query = "UPDATE `swimmerdatabase`.`"+table_name[age_group-1]+"` SET `"+col_name+"` ="+value+" where id ="+ id;
        PreparedStatement ps = connection.prepareStatement(query);
        int status = ps.executeUpdate();
        if(status !=0){

            System.out.println("database connected and updated");}

    }
    public static void deleteSpecificData(int id,int age_group) throws SQLException{
        String query= "DELETE FROM `swimmerdatabase`.`"+table_name[age_group]+"`WHERE `id`="+id;
        //= "delete from studentdatabase.student where id = ?";
        PreparedStatement ps = connection.prepareStatement(query);
        int status = ps.executeUpdate();
        if(status !=0){

            System.out.println("database connected and deleted");}

    }

    public void addData() throws SQLException{
        java.util.Date now = new java.util.Date();
        Random rand = new Random();
        int minDay = (int)LocalDate.of(1984, Month.JANUARY,1).toEpochDay();
        int maxDay = (int)LocalDate.of(2019, 2,3).toEpochDay();
        long randomDay = minDay+rand.nextInt(maxDay-minDay);
        LocalDate birthOfDate = LocalDate.ofEpochDay(randomDay);
        int age =16;
        for(int season =1; season <=4;season++){

            for(int swimmers =1; swimmers<12; swimmers++){
                // deleteData(table_name[season-1]);
                String sex;
                int sex1=rand.nextInt(2);
                if(sex1==1){
                    sex="F";
                }else{
                    sex="M";
                }
                insertData(season,"name"+swimmers,sex,java.sql.Date.valueOf(birthOfDate),age+rand.nextInt(5),rand.nextInt(101),1+rand.nextInt(4),season,age+15);

            }
            System.out.println("*************************************"+table_name[season-1]+"*****************************************************");
//fetchData(table_name[season-1]);
            age+=5;
        }
    }

    public  void fetchData(String table_name,ArrayList<Swimmer> catchedData) throws SQLException{
        connection =DriverManager.getConnection(url, username, password);
        String query ="SELECT * FROM `swimmerdatabase`. `"+table_name+"`";
        PreparedStatement ps = connection.prepareStatement(query);
        // execute the query, and get a java resultset
        ResultSet rs = ps.executeQuery(query);

        // iterate through the java resultset
        while (rs.next())
        {
            grwonUp(rs);

            Swimmer swimmer = new Swimmer();

            swimmer.setName(rs.getString("name"));
            swimmer.setSeason(rs.getInt("season"));
            swimmer.setAge_group(rs.getInt("age_group"));
            swimmer.setResult(rs.getInt("comp_result"));
            swimmer.setMaxAge(rs.getInt("max_age"));
            swimmer.setSex(rs.getString("sex"));
            swimmer.setBirthOfDate(rs.getDate("birth_of_date"));
            swimmer.setAge(rs.getInt("age"));
            swimmer.setId(rs.getInt("id"));

            catchedData.add(swimmer);



            int id = rs.getInt("id");
            String firstName = rs.getString("name");
            int age = rs.getInt("age");
            Date birthOfDate= rs.getDate("birth_of_date");
            int season = rs.getInt("season");
            int result= rs.getInt("comp_result");
            //data_1.add(rs);

// print the results

            //  System.out.format("%s, %s, %s, %s, %s ,%S\n", id, firstName,age, dateCreated, numPoints,season);
            // data_1.add(new Swimmer(firstName,numPoints,season,1));

        }
    }
    public  void grwonUp(ResultSet rs) throws SQLException {
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("MM-dd ");
        // System.out.println(formatter.format(date));
        Date bDate =rs.getDate("birth_of_date");
        SimpleDateFormat formatter2 = new SimpleDateFormat("MM-dd ");
        String format=formatter.format(bDate);



        String update ="age";
        if (format.equals(formatter.format(date))){

            // update(int age_group,int id,String col_name,int value)
            Database.update(rs.getInt("age_group"),rs.getInt("id"),update,rs.getInt("age")+1);


        }
        if (rs.getInt("age")==rs.getInt("max_age")){
            Database.insertData(rs.getInt("age_group")+1,rs.getString("name"),rs.getString("sex"),rs.getDate("birth_of_date"),rs.getInt("age"),rs.getInt("comp_result"),rs.getInt("season"),rs.getInt("age_group"),rs.getInt("max_age"));
            Database.deleteSpecificData(rs.getInt("id"),rs.getInt("age_group"));
        }



    }

    public  static Database getInstance(){

    return instance;
    }
}

