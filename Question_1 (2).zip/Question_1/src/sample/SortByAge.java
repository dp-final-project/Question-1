package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 * @author maggie
 */
class SortByAge extends SortSwimmers{
    ObservableList<Swimmer> list = FXCollections.observableArrayList();
    public  void sort(ArrayList<Swimmer> datas){
        System.out.println("*********************** sort by Age******************************");
        System.out.println("ID_______Name______Sex______age_______season_______computation Result");
        int i =0;

      Collections.sort(datas, new Comparator<Swimmer>() {

            @Override
            public int compare(Swimmer t, Swimmer t1) {
                return t.age - t1.age;
            }
        });
       // list.add("S name    Sex     Age     Season     Result");
        for(Swimmer data : datas){
            System.out.println(i+"________"+data.name+"_____"+data.sex+"________"+data.age+"_________"+data.season+"______________"+data.result);
           // list.add(data.name+"     "+data.sex+"          "+data.age+"           "+data.season+"             "+data.result);
list.add(data);
            //System.out.println(i+"________"+data.name+"_____"+data.sex+"________"+data.age+"_________"+data.season+"______________"+data.result);
            i++;


        }
    }
    public ObservableList<Swimmer> list(ArrayList<Swimmer> datas){

        sort( datas);
        return list;

    }

}