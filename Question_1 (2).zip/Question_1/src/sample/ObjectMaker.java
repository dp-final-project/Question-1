package sample;

import java.sql.SQLException;

public class ObjectMaker {
    SwimmersData sData;

    public ObjectMaker() throws SQLException {

        this.sData = new SwimmersData();
        try {
            sData.viewData();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Swimmer getSwimmer(){
    return new Swimmer();

}
    public SwimmersData getSwimmersData(){

        return (SwimmersData)sData.clone();

    }
    public SortBySex getSortBySex(){

        return new SortBySex();
    }
    public SortByAge getSortByAge(){
        return new SortByAge();
    }
public SortByTime getSortByTime(){
        return new SortByTime();

}

public WhoDidBest getWhoDidBest(){

        return new WhoDidBest(getSwimmersData().getSwimmersCollection());
}


}
