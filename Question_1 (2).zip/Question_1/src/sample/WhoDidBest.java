package sample;



import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.ArrayList;
import java.util.Collections;
//import static swimmers.Swimmers.arranged_1;
//import static swimmers.Swimmers.outer;
//import static swimmers.Swimmers.whoDidBest;

/**
 *
 * @author maggie
 */
class WhoDidBest {

    static ArrayList<Swimmer> arranged_1 = new ArrayList<Swimmer>(Collections.nCopies(4,null));
    static ArrayList<Swimmer> arranged_2 = new ArrayList<Swimmer>(Collections.nCopies(4,null));
    static ArrayList<Swimmer> arranged_3 = new ArrayList<Swimmer>(Collections.nCopies(4,null));
    static ArrayList<Swimmer> arranged_4 = new ArrayList<Swimmer>(Collections.nCopies(4,null));
    static ArrayList<Swimmer> data_1;
    static int result_list[]={0,0,0,0};

   ObservableList<Swimmer> list = FXCollections.observableArrayList();

    static ArrayList<ArrayList<Swimmer>> outer= new ArrayList<ArrayList<Swimmer>>();


    public WhoDidBest(ArrayList<Swimmer> datas){
        this.data_1=datas;
        outer.add(arranged_1);
        outer.add(arranged_2);
        outer.add(arranged_3);
        outer.add(arranged_4);
    }


    public  void whoDidBest(int season,int age_group,int result){
        for(Swimmer data:data_1){
            if(data.season == season && data.age_group == age_group&&data.result>result){
                result=data.result;
                //System.out.println("######## age group :"+data.age_group+"######### Result : "+result);
                if(season ==1){
                    switch (age_group) {
                        case 1: arranged_1.set(0,data);
                            break;
                        case 2: arranged_1.set(1,data);
                            break;
                        case 3: arranged_1.set(2,data);
                            break;
                        case 4: arranged_1.set(3,data);
                            break;

                    }


                }else if(season ==2){
                    switch (age_group) {
                        case 1: arranged_2.set(0,data);
                            break;
                        case 2: arranged_2.set(1,data);
                            break;
                        case 3: arranged_2.set(2,data);
                            break;
                        case 4: arranged_2.set(3,data);
                            break;

                    }
                }else if(season ==3){
                    switch (age_group) {
                        case 1: arranged_3.set(0,data);
                            break;
                        case 2: arranged_3.set(1,data);
                            break;
                        case 3: arranged_3.set(2,data);
                            break;
                        case 4: arranged_3.set(3,data);
                            break;

                    }
                }else if(season ==4){
                    switch (age_group) {
                        case 1: arranged_4.set(0,data);
                            break;
                        case 2: arranged_4.set(1,data);
                            break;
                        case 3: arranged_4.set(2,data);
                            break;
                        case 4: arranged_4.set(3,data);
                            break;

                    }
                }

            }continue;

        }

    }
    public  ObservableList<Swimmer>  whoDidBest_In(){

        for(int season =1; season <=4;season++){

            for(int age_group =1; age_group<=4;age_group++){

                whoDidBest(season,age_group,result_list[age_group-1]);}



        }

        for(int k=0;k<4;k++){
           // list.add("############################################# WHO DID BEST IN SEASON -"+(k+1)+"##########################################################################");

           // list.add("NAME          AGE GROUP           SEASON");
            System.out.println("############################################# WHO DID BEST IN SEASON -"+(k+1)+"##########################################################################");
            System.out.println("NAME          AGE GROUP           SEASON");
            for(Swimmer data: outer.get(k)){
                // System.out.println("NAME     AGE GROUP    SEASON");
                System.out.println(data.name+"            "+data.age_group+"                   "+data.season);
                list.add(data);
            }
        }
        return list;

    }

}
