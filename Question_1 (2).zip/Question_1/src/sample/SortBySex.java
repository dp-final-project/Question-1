package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.ArrayList;

/**
 *
 * @author maggie
 */
class SortBySex extends SortSwimmers {
    String sex;
    ObservableList<Swimmer> list = FXCollections.observableArrayList();

    public   void sort( ArrayList<Swimmer> datas){
        System.out.println("*********************** sort by sex******************************");
        System.out.println("ID_______Name______Sex______age_______season_______computation Result");
        if(sex.equalsIgnoreCase("F")){
            int i =0;
            //list.add("ID_______Name______Sex______age_______season_______computation Result");
            for(Swimmer data : datas){
                if(data.sex.equalsIgnoreCase("F")){

                    System.out.println(i+"________"+data.name+"_____"+data.sex+"________"+data.age+"_________"+data.season+"______________"+data.result);
                    //list.add(i+"        "+data.name+"          "+data.sex+"             "+data.age+"              "+data.season+"              "+data.result);
                    list.add(data);
                    i++;}
            }
        }else{
            System.out.println("ID_______Name______Sex______age_______season_______computation Result");
           // list.add("ID_______Name______Sex______age_______season_______computation Result");
            int i =0;
            for(Swimmer data : datas){
                if(data.sex.equalsIgnoreCase("M")){
                    //list.add(i+"        "+data.name+"                    "+data.sex+"                  "+data.age+"                     "+data.season+"                    "+data.result);
                    System.out.println(i+"________"+data.name+"_____"+data.sex+"________"+data.age+"_________"+data.season+"______________"+data.result);
                    list.add(data);
                    i++;
            }
        }}
    }


    public void setSex(String sex){
        this.sex=sex;

    }
    public ObservableList<Swimmer> list(ArrayList<Swimmer> datas){

        sort( datas);
        return list;

    }
}
