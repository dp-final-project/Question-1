package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;


import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class Controller implements Initializable {

    @FXML private ToggleGroup gender;
//    @FXML private RadioButton radioF;
//    @FXML private RadioButton radioM;


    @FXML private TableView leftTable;
    @FXML private TableView rightTable;
    @FXML private TableColumn <Swimmer,String> name;
    @FXML private TableColumn<Swimmer,Integer> result;
    @FXML private TableColumn<Swimmer,String> sex;
    @FXML private TableColumn<Swimmer,Integer> age;

    @FXML private TableColumn <Swimmer,String> name1;
    @FXML private TableColumn<Swimmer,Integer> result1;
    @FXML private TableColumn<Swimmer,String> sex1;
    @FXML private TableColumn<Swimmer,Integer> age1;

    ObjectMaker objectMaker = new ObjectMaker();

    ObservableList<Swimmer> lists = FXCollections.observableArrayList();

    public Controller() throws SQLException {
    }

    @FXML
    private void sortByAge(ActionEvent event) {
        SortByAge sortByAge = objectMaker.getSortByAge();

        lists =  sortByAge.list(objectMaker.getSwimmersData().getSwimmersCollection());


       rightTable.setItems(lists);
        name.setCellValueFactory(new PropertyValueFactory<Swimmer,String>("name"));
        result.setCellValueFactory(new PropertyValueFactory<Swimmer,Integer>("result"));
        sex.setCellValueFactory(new PropertyValueFactory<Swimmer,String>("sex"));
        age.setCellValueFactory(new PropertyValueFactory<Swimmer,Integer>("age"));


    }
    @FXML
    private void sortBySex(ActionEvent event){
        SortBySex sortBySex = objectMaker.getSortBySex();
        RadioButton selectedRadioButton = (RadioButton) gender.getSelectedToggle();
        String toogleGroupValue = selectedRadioButton.getText();
        sortBySex.setSex(toogleGroupValue);

        rightTable.setItems(sortBySex.list(objectMaker.getSwimmersData().getSwimmersCollection()));
        name.setCellValueFactory(new PropertyValueFactory<Swimmer,String>("name"));
        result.setCellValueFactory(new PropertyValueFactory<Swimmer,Integer>("result"));
        sex.setCellValueFactory(new PropertyValueFactory<Swimmer,String>("sex"));
        age.setCellValueFactory(new PropertyValueFactory<Swimmer,Integer>("age"));

    }


    @FXML
    private void whoDidBest(ActionEvent event) throws IOException {

        Parent executiveView = FXMLLoader.load(getClass().getResource("report.fxml"));
        Scene executiveScene = new Scene(executiveView);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(executiveScene);
        window.show();




    }



    @Override
    public void initialize(URL location, ResourceBundle resources) {
        SortByTime sTime= objectMaker.getSortByTime();


leftTable.setItems(sTime.list(objectMaker.getSwimmersData().getSwimmersCollection()));
        name1.setCellValueFactory(new PropertyValueFactory<Swimmer,String>("name"));
        result1.setCellValueFactory(new PropertyValueFactory<Swimmer,Integer>("result"));
        sex1.setCellValueFactory(new PropertyValueFactory<Swimmer,String>("sex"));
        age1.setCellValueFactory(new PropertyValueFactory<Swimmer,Integer>("age"));

  //   listLeft.setItems(sTime.list(sData.getSwimmersCollection()));



    }


}




