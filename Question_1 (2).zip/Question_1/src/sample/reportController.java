package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;


import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class reportController implements Initializable {
  //  @FXML private ListView reportList;
    @FXML private TableView report;
    @FXML private TableColumn <Swimmer,String> name;
    @FXML private TableColumn<Swimmer,Integer> result;
    @FXML private TableColumn<Swimmer,String> sex;
    @FXML private TableColumn<Swimmer,Integer> age;
    @FXML private TableColumn<Swimmer,Integer> season;

    @FXML private TableColumn<Swimmer,Integer> age_group;



    //@FXML private,sex,age,season,age_group;
   // SwimmersData sData=new SwimmersData();
    ObjectMaker objectMaker = new ObjectMaker();

    public reportController() throws SQLException {
    }

    @FXML private void back(ActionEvent event) throws IOException {

        Parent executiveView = FXMLLoader.load(getClass().getResource("sample.fxml"));
        Scene executiveScene = new Scene(executiveView);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(executiveScene);
        window.show();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

//        TableColumn name = new TableColumn("name");
//        TableColumn result = new TableColumn("result");
//        TableColumn sex = new TableColumn("sex");
//        TableColumn age = new TableColumn("age");
//        TableColumn season = new TableColumn("season");
//        TableColumn age_group = new TableColumn("age_group");

//report.getColumns().addAll(name,result,sex,age,season,age_group);

        WhoDidBest whoDidBest=new WhoDidBest(objectMaker.getSwimmersData().getSwimmersCollection());
        //System.out.println(whoDidBest.whoDidBest_In());

        report.setItems(whoDidBest.whoDidBest_In());


        name.setCellValueFactory(new PropertyValueFactory<Swimmer,String>("name"));
        result.setCellValueFactory(new PropertyValueFactory<Swimmer,Integer>("result"));
        sex.setCellValueFactory(new PropertyValueFactory<Swimmer,String>("sex"));
        age.setCellValueFactory(new PropertyValueFactory<Swimmer,Integer>("age"));
        season.setCellValueFactory(new PropertyValueFactory<Swimmer,Integer>("season"));
        age_group.setCellValueFactory(new PropertyValueFactory<Swimmer,Integer>("age_group"));


    }
}
